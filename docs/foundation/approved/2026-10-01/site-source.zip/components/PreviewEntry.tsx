'use client';
import { useEffect, useState } from 'react';
import FoundationPreview from './foundation/FoundationPreview';
import { isFoundationScenario, type FoundationScenario } from '@/lib/frontend/foundation-preview';
import { readPreviewPreferences, type FactorKey, type PreviewPreferences } from '@/lib/frontend/factor-preview';
import type { HomeMemberKey } from '@/lib/frontend/home-household';
export default function PreviewEntry({ initialFactor, initialFamily = false, initialMember }: { initialFactor?: FactorKey; initialFamily?: boolean; initialMember?: HomeMemberKey }) {
  const [review, setReview] = useState<{ scenario: FoundationScenario; preferences: PreviewPreferences } | null>(null);
  useEffect(() => {
    const params = Object.fromEntries(new URLSearchParams(window.location.search));
    setReview({
      scenario: isFoundationScenario(params.scenario) ? params.scenario : 'shell',
      preferences: readPreviewPreferences({ appearance: 'dark', motion: 'full', ...params }),
    });
  }, []);
  if (!review) return <p role="status" style={{ padding: '2rem', textAlign: 'center' }}>Opening HALO...</p>;
  return <FoundationPreview initialScenario={review.scenario} initialFactor={initialFactor} initialFamily={initialFamily} initialMember={initialMember} preferences={review.preferences} />;
}

