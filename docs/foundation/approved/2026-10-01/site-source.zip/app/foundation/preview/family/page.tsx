import PreviewEntry from '@/components/PreviewEntry';
export default function FamilyPage() { return <PreviewEntry initialFamily />; }
