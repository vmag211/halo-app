import PreviewEntry from '@/components/PreviewEntry';
export default function PreviewPage() { return <PreviewEntry />; }

