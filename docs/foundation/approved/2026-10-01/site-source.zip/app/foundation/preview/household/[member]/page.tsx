import { notFound } from 'next/navigation';
import PreviewEntry from '@/components/PreviewEntry';
import { homeMemberKeys, isHomeMemberKey } from '@/lib/frontend/home-household';

export const dynamicParams = false;
export function generateStaticParams() { return homeMemberKeys.map(member => ({ member })); }

export default async function HomeMemberPage({ params }: { params: Promise<{ member: string }> }) {
  const { member } = await params;
  if (!isHomeMemberKey(member)) notFound();
  return <PreviewEntry initialMember={member} />;
}
