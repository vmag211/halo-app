import { notFound } from 'next/navigation';
import PreviewEntry from '@/components/PreviewEntry';
import { factorKeys, isFactorKey } from '@/lib/frontend/factor-preview';
export const dynamicParams = false;
export function generateStaticParams() { return factorKeys.map(factor => ({ factor })); }
export default async function FactorPage({ params }: { params: Promise<{ factor: string }> }) {
  const { factor } = await params;
  if (!isFactorKey(factor)) notFound();
  return <PreviewEntry initialFactor={factor} />;
}

