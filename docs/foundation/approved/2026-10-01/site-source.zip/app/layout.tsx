import type { Metadata, Viewport } from 'next';
import localFont from 'next/font/local';
import './globals.css';
import './onboarding.css';
import './onboarding-mobile.css';
const instrument = localFont({ src: '../public/fonts/instrument-sans-latin.woff2', variable: '--font-instrument', display: 'swap', weight: '400 700', fallback: ['Arial'] });
const fraunces = localFont({ src: '../public/fonts/fraunces-latin.woff2', variable: '--font-fraunces', display: 'swap', weight: '100 900', fallback: ['Georgia'] });
export const metadata: Metadata = { title: 'HALO Wireframe Review', description: 'Editable HALO frontend wireframes using sample data.', robots: { index: false, follow: false }, icons: { icon: '/halo-icon.png', apple: '/halo-icon.png' } };
export const viewport: Viewport = { width: 'device-width', initialScale: 1, viewportFit: 'cover', themeColor: '#102d31' };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en" className={`${instrument.variable} ${fraunces.variable} h-full antialiased`}><body className="min-h-full flex flex-col">{children}</body></html>;
}

