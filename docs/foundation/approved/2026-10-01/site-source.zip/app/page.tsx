import PreviewEntry from '@/components/PreviewEntry';
import PreviewLayout from './foundation/preview/layout';
export default function Page() { return <PreviewLayout><PreviewEntry /></PreviewLayout>; }

